/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.parcialprogramacion;
import java.util.*;
/**
 *
 * @author molin
 */
public class ParcialProgramacion {

    public static void main(String[] args) {
       Ejercicio8();
    }
   public static void Ejercicio1(){
      Scanner sc = new Scanner(System.in);
        System.out.println("tiempo en segundos: ");
        int segundosUsuario = sc.nextInt();
        int dias = segundosUsuario / 86400;
        int total = segundosUsuario % 86400;
        int horas = total / 3600; 
        total=total % 3600;
        int minutos = total / 60;
        total=total% 60;
        int segundos = total;
        System.out.println("El periodo de tiempo es: " + dias + " días " + horas + " horas " + minutos + " minutos " + segundos + " segundos");   
   }
   public static void Ejercicio2(){
       Scanner sc = new Scanner(System.in);
       System.out.print("dia: ");
       int dia = sc.nextInt();
       System.out.print("mes: ");
       int mes = sc.nextInt();
       System.out.print("año: ");
       int año = sc.nextInt();

       boolean validacionFecha = true;
       if(mes < 1 || mes > 12){
           validacionFecha = false;
       }else{
           int diasMeses = 0;
           switch(mes){
               case 2 -> {
                   if((año % 4 == 0)){
                       diasMeses = 29;
                   }else{
                       diasMeses = 28;
                   }
               }
               case 4, 6, 9, 11 -> diasMeses = 30;
               default -> diasMeses = 31;
           }

           if(dia < 1 || dia > diasMeses){
               validacionFecha = false;
           }
       }
       if(validacionFecha){
           int TotalDias = dia;
           for(int i=1; i<mes; i++){
               switch(i){
                    case 2 -> {
                        if((año % 4 == 0)){
                            TotalDias= TotalDias+ 29;
                        }else{
                            TotalDias= TotalDias + 28;
                        }
                   }
                   case 4, 6, 9, 11 -> TotalDias= TotalDias+ 30;
                   default -> TotalDias = TotalDias+ 31;
               }
           }
           System.out.printf("Valido y han pasaron %d dias desde el inicio del año.", TotalDias);
       }else{
           System.out.println("Fecha no valida.");
       }
       
   }
   public static void Ejercicio3(){
       Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el número de latas a apilar: ");
        int n = sc.nextInt();
        sc.close();

        int level = 1;
        int cansPerLevel = 1;
        while (cansPerLevel <= n) {
            if (cansPerLevel == n) {
                System.out.println("El número " + n + " se puede apilar triangularmente.");
                return;
            }
            level++;
            cansPerLevel += level;
        }
        
        int nearestStackableNum;
        if (n < cansPerLevel - level) {
            nearestStackableNum = (level - 1) * (level - 2) / 2;
        } else {
            nearestStackableNum = cansPerLevel - level;
        }
        System.out.println("El número " + n + " no se puede apilar triangularmente.");
        System.out.println("El número de latas más cercano que se puede apilar es " + nearestStackableNum);
   }
   public static void Ejercicio4(){
        Scanner sc = new Scanner(System.in);
        System.out.print("elementos:  ");
        int elementos = sc.nextInt();
        int numero1 = 1, numero2 = 2, suma;
        for(int i=1; i<=elementos; i++) {
            System.out.print(numero2 + "\n");
            suma = numero1 + numero2;
            numero1 = numero2;
            numero2 = suma;
        }
    }  
   public static void Ejercicio5(){
     Scanner input = new Scanner(System.in);

        System.out.print("Base del triangulo ");
        int base = input.nextInt();

        System.out.print("Derecha o izquieda ");
        String lado = input.next();

        for (int i = 1; i <= base; i++) {
            if(lado.equalsIgnoreCase("izquierda")) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
            } else {
                for(int j = 1; j <= base - i + 1; j--){
                    System.out.print("*");
                }
            }
            System.out.println();
        }
    
        
   }
   public static void Ejercicio6(){
       Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce una frase: ");
        String frase = scanner.nextLine();

        String[] palabras = frase.split(" ");
        int cantidadPalabras = palabras.length;
        int totalLetras = 0;
  
        for (String i : palabras) {
            totalLetras= totalLetras + i.length();
        }

      
        System.out.println("Palabras: "+ cantidadPalabras);
        System.out.println("Caracteres: "+ totalLetras);
   }
   public static void Ejercicio7(){
     Scanner sc = new Scanner(System.in);
     int size,size2;
     System.out.println("Tamaño primer vector");
     size= sc.nextInt();
     int[] arr1 = new int[size];
     
      System.out.println("Tamaño segundo vector");
     size2= sc.nextInt();
     int[] arr2 = new int[size2];
     
     for(int i=0; i<size; i++){
         System.out.println("Ingrese valores del vector 1");
         arr1[i]=sc.nextInt();
     }
     for(int j=0; j<size2; j++){
          System.out.println("Ingrese valores del vector 2");
         arr2[j]=sc.nextInt();
     }
     int[] arr3 = new int[arr1.length+arr2.length];
     System.arraycopy(arr1, 0, arr3, 0, size);
     System.arraycopy(arr2, 0, arr3, size, size2);
     Arrays.sort(arr3);
     System.out.println("Ascendente: "+ Arrays.toString(arr3));
    
     
     for (int i = 0; i < arr3.length - 1; i++) { //elemento más grande del arreglo se coloca de primero.
        for (int j = 0; j < arr3.length - i - 1; j++) { 
        if (arr3[j] < arr3[j + 1]) { 
            int cont = arr3[j];
            arr3[j] = arr3[j + 1];
            arr3[j + 1] = cont;
            }
            }
        }
System.out.print("Descendente: ");
      for (int i = 0; i < arr3.length; i++) {
        System.out.print(Arrays.toString(arr3));
        break;
        }
   }
   public static void Ejercicio8(){
       Scanner input= new Scanner(System.in);
        System.out.print("Ingrese el número de materias: ");
        int numMaterias = input.nextInt();
        input.nextLine();


        String[][] materias = new String[numMaterias][13];
        int totalMensual = 0;
        int maxHoras = 0;
        int minHoras = Integer.MAX_VALUE;
        String maxMateria = "";
        String minMateria = "";

        for (int i = 0; i < numMaterias; i++) {
            System.out.println("\nMateria " + (i + 1) + ":");
            System.out.print("Ingrese el nombre de la materia: ");
            materias[i][0] = input.nextLine();
            int totalAnual = 0;
            for (int j = 1; j <= 12; j++) {
                System.out.print("Ingrese las horas de estudio para el mes " + j + ": ");
                int horas = input.nextInt();
                materias[i][j] = String.valueOf(horas);
                totalAnual += horas;
                if (horas > maxHoras) {
                    maxHoras = horas;
                    maxMateria = materias[i][0];
                }
                if (horas < minHoras) {
                    minHoras = horas;
                    minMateria = materias[i][0];
                }
            }
            materias[i][12] = String.valueOf(totalAnual);
            totalMensual += totalAnual;
            input.nextLine();
        }

    
        System.out.println("\nResultados:");
        for (int i = 0; i < numMaterias; i++) {
            System.out.println("Total Mensual: " + materias[i][12]+ " De la materia "+ (i+1));
        }
        System.out.println("Total Anual: " + totalMensual);

   
        int countMax = 0;
        int countMin = 0;
        for (int i = 0; i < numMaterias; i++) {
            int totalHoras = Integer.parseInt(materias[i][12]);
            if (totalHoras == maxHoras) {
                countMax++;
                if (countMax == 1) {
                    maxMateria = materias[i][0] + " (" + maxHoras + " horas)";
                } else {
                    maxMateria += ", " + materias[i][0] + " (" + maxHoras + " horas)";
                }
            }
            if (totalHoras <= minHoras) {
                countMin++;
                if (countMin == 1) {
                    minMateria = materias[i][0] + " (" + minHoras + " horas)";
                } else {
                    minMateria += ", " + materias[i][0] + " (" + minHoras + " horas)";
                }
            }
        }
        System.out.println("Materia(s) con más horas: " + maxMateria);
        System.out.println("Materia(s) con menos horas: " + minMateria);   

   }
}